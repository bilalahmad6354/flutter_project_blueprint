import 'package:surf_costa/data/data_source/interface/home_data_source.dart';
import 'package:surf_costa/data/service/interface/auth_api_service.dart';
import 'package:surf_costa/data/service/interface/home_api_service.dart';

import '../../core/dio/remote_response.dart';
import '../../data/repository/home_repository_impl.dart';
import '../models/home/home.dart';

final HomeRepository homeRepository = HomeRepositoryImpl(homeApiService, homeLocalDatasource);

abstract class HomeRepository {
}
