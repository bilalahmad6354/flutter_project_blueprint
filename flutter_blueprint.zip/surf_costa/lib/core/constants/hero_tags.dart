final heroTags = _HeroTags();

class _HeroTags {
  String newsImageTag = "newsImageTag";
}
