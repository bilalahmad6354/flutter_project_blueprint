class Assets {
  Assets._();
}