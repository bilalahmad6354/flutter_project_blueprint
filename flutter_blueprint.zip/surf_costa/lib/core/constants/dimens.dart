class Dimens {
  Dimens._();

  //for all screens
  static const double horizontalPadding = 12.0;
  static const double verticalPadding = 12.0;
}
