// ignore_for_file: constant_identifier_names

const int STATUS_OK = 200;
const int STATUS_NOT_FOUND = 404;
const int STATUS_INVALID_REQUEST = 404;
const int STATUS_INTERNAL_SERVER_ERROR = 500;
