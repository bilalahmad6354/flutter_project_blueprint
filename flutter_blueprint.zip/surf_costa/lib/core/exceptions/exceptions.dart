
class InternetNotAvailableException implements Exception {


}

class SomethingWentWrongException implements Exception {
  @override
  String toString() {
    return "something_went_wrong";

  }
}