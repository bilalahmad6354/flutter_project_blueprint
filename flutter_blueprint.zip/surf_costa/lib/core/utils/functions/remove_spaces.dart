String removeSpaces(String text) {
  return text.replaceAll(' ', '');
}
