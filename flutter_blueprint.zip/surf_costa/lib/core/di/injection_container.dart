import 'package:flutter/cupertino.dart';
import 'package:get_it/get_it.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:surf_costa/core/constants/color.dart';

import '../utils/preferences/preferences_service.dart';
import '../utils/preferences/preferences_service_impl.dart';
import 'package:flutter_flavor/flutter_flavor.dart';

final getIt = GetIt.instance;

class DependencyInjection {
  static Future<void> setup() async {

    FlavorConfig(
        name: "DEVELOP",
        color: Colors.red,
        location: BannerLocation.bottomStart,
        variables: {
          "counter": 0,
          "BASE_URL": "https://www.example.com",
        }
    );


    // FlavorConfig(
    //     name: "PRODUCTION",
    //     color: Colors.red,
    //     location: BannerLocation.bottomStart,
    //     variables: {
    //       "counter": 0,
    //       "baseUrl": "https://www.example.com",
    //     }
    // );
    // Register SharedPreferences dependency
    getIt.registerLazySingletonAsync<SharedPreferences>(
      () => SharedPreferences.getInstance(),
    );
    await getIt.isReady<SharedPreferences>(); // Add this line
    getIt.registerLazySingleton<PreferencesService>(
      () => PreferencesServiceImpl(
        sharedPreferences: getIt<SharedPreferences>(),
      ),
    );

    // Other dependencies can be registered here
    // getIt.registerSingleton<YourServiceClass>(YourServiceClass());
  }
}
