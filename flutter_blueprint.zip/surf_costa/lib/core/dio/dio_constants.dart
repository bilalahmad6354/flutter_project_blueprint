final dioConstants = _DioConstants();

class _DioConstants {
  int maxRetries = 3;
}
