
import 'package:surf_costa/core/exceptions/exceptions.dart';

class RemoteResponse<T> {
  bool successBool;
  T? data;
  Exception? exception;

  RemoteResponse(this.successBool, this.data, this.exception);

  static RemoteResponse<T> success<T>(T? data) {
    return RemoteResponse<T>(true, data, null);
  }

  static RemoteResponse<T> defaultValue<T>() {
    return RemoteResponse<T>(false, null, null);
  }

  static RemoteResponse<T> internetConnectionError<T>() {
    final internetNotAvailableException = InternetNotAvailableException();
    return RemoteResponse<T>(false, null, internetNotAvailableException);
  }

  static RemoteResponse<T> somethingWentWrong<T>(String message) {
    return RemoteResponse<T>(false, null , Exception(message));
  }


  static RemoteResponse<T> serverReturnedError<T>(String message) {
    return RemoteResponse<T>(false, null , Exception(message));
  }
}
