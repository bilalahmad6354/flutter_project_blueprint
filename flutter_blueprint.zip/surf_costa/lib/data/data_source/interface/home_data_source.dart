import 'package:surf_costa/data/data_source/home_local_data_source_impl.dart';

final HomeLocalDatasource homeLocalDatasource = HomeLocalDataSourceImpl( );
abstract class HomeLocalDatasource {

}
