import 'package:surf_costa/data/data_source/auth_local_data_source_impl.dart';

final AuthLocalDatasource authLocalDatasource = AuthLocalDataSourceImpl( );
abstract class AuthLocalDatasource {

}
