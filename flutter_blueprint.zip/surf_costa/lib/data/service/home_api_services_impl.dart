import 'package:dio/dio.dart';
import 'package:surf_costa/core/constants/status_code.dart';
import 'package:surf_costa/core/dio/remote_response.dart';
import 'package:surf_costa/data/provider/generic_data_provider.dart';
import 'package:surf_costa/domain/models/home/home.dart';
import 'package:flutter_logger_plus/flutter_logger_plus.dart';

import '../../core/config/config.dart';
import '../../core/dio/api.dart';
import 'interface/home_api_service.dart';

class HomeApiServiceImpl extends HomeApiService {
  final Api _api;
  HomeApiServiceImpl(this._api);

}