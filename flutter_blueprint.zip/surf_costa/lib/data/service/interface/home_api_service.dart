import 'package:dio/dio.dart';
import 'package:surf_costa/core/dio/remote_response.dart';
import 'package:surf_costa/domain/models/home/home.dart';

import '../../../core/dio/api.dart';
import '../home_api_services_impl.dart';

final HomeApiService homeApiService = HomeApiServiceImpl(Api());
abstract class HomeApiService {
}
