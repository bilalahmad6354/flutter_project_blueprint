import 'package:dio/dio.dart';
import 'package:surf_costa/core/dio/remote_response.dart';
import 'package:surf_costa/data/service/auth_api_services_impl.dart';
import 'package:surf_costa/domain/models/home/home.dart';

import '../../../core/dio/api.dart';
import '../home_api_services_impl.dart';

final AuthApiService authApiService = AuthApiServiceImpl(Api());
abstract class AuthApiService {
  Future<RemoteResponse<Home>> getHomeData();
}
