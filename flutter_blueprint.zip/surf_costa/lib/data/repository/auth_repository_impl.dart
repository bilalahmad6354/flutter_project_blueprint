import 'package:either_dart/either.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:surf_costa/core/exceptions/exceptions.dart';
import 'package:surf_costa/data/data_source/auth_local_data_source_impl.dart';
import 'package:surf_costa/data/data_source/interface/auth_data_source.dart';
import 'package:surf_costa/data/service/interface/auth_api_service.dart';
import 'package:surf_costa/domain/repository/auth_repository.dart';

import '../../core/dio/remote_response.dart';
import '../../core/utils/network/network.dart';
import '../../domain/models/home/home.dart';

class AuthRepositoryImpl extends AuthRepository {
  final AuthLocalDatasource _authLocalDatasource;
  final AuthApiService _authApiService;
  AuthRepositoryImpl(this._authApiService, this._authLocalDatasource);

  @override
  Future<Either<Exception, Home?>> getHomeData() async {
    if (!await isNetworkAvailable) {
      return Left(InternetNotAvailableException());
    }
    try{
      final result = await _authApiService.getHomeData();
      if(result.exception != null) {
        return Left(result.exception!);
      }else{
        return Right(result.data);
      }
    }catch(ex){
      return Left(Exception(ex.toString()));
    }
  }
}
