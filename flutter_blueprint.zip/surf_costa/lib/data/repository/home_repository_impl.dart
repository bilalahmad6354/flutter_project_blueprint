import 'package:surf_costa/data/data_source/interface/home_data_source.dart';
import 'package:surf_costa/data/service/interface/home_api_service.dart';

import '../../core/dio/remote_response.dart';
import '../../core/utils/network/network.dart';
import '../../domain/models/home/home.dart';
import '../../domain/repository/home_repository.dart';
import '../data_source/home_local_data_source_impl.dart';

class HomeRepositoryImpl extends HomeRepository {
  final HomeLocalDatasource _homeLocalDatasource;
  final HomeApiService _homeApiService;
  HomeRepositoryImpl( this._homeApiService, this._homeLocalDatasource,);

}
