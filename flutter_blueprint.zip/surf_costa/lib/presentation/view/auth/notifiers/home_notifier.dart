

import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:surf_costa/core/di/injection_container.dart';
import 'package:surf_costa/domain/models/home/home.dart';
import 'package:surf_costa/domain/repository/auth_repository.dart';


part 'home_notifier.g.dart';



@riverpod
class HomeNotifier extends _$HomeNotifier {
  Future<Home?> addToHome() async {
    final _authRepository = getIt.get<AuthRepository>();
    final result = await _authRepository.getHomeData();

    if(result.isLeft){
      throw result.left;
    }else{
      return result.right;
    }
  }

  @override
  Home? build(){
    state = null;
    return null;
  }


}