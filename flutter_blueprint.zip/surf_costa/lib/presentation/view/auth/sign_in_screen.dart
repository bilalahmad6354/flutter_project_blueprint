import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:surf_costa/core/di/injection_container.dart';
import 'package:surf_costa/domain/models/home/home.dart';
import 'package:surf_costa/domain/repository/auth_repository.dart';
import 'package:surf_costa/presentation/view/auth/notifiers/home_notifier.dart';



class AuthPage extends ConsumerWidget {
  const AuthPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {

    final result = ref.watch(homeNotifierProvider);

    return  Scaffold(
      body: switch(result){
        AsyncData(:final value) => Text('Activity: ${value?.id}'),
        AsyncError(:final error) => const Text('Oops, something unexpected happened'),
        _ => const CircularProgressIndicator(),
      },
    );
  }
}
