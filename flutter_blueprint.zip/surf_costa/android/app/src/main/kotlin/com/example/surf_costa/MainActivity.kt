package com.example.surf_costa

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
